import java.util.*;
import java.util.stream.Collectors;

public class NewExample {
    public static void main(String[] args) {

        Scanner in = new Scanner(System.in);
        System.out.println("1,2 Задание-------------------------");
        System.out.println("Введите размер массива");
        int size = in.nextInt();
        int[] arr = new int[size];
        int[] arr2 = new int[size];
        Random random = new Random();
        for (int i = 0; i < size; i++) {
            arr[i] = random.nextInt(10);
            arr2[i] = random.nextInt(16);
        }
        System.out.println("Массив arr : ");
        System.out.println(Arrays.toString(arr));
        System.out.println("Array 2: ");
        System.out.println(Arrays.toString(arr2));
        int[] arrResult = filterEvenNumbers(arr);
        int[] arrResult2 = findCommonElements(arr, arr2);
        System.out.println("Массив arrResult :");
        System.out.println(Arrays.toString(arrResult));
        System.out.println("Common Elements: ");
        System.out.println(Arrays.toString(arrResult2));
        System.out.println("-----------------------------------");
        System.out.println("3 Задание--------------------------------");
        String string = "Напишите функцию, которая принимает на вход список " +
                "строк и возвращает новый список, содержащий только те строки, " +
                "которые начинаются с большой буквы. G56 Arr()r ";
        String substring = "список";

        List<String> strings = List.of(string.split(" "));
        System.out.println("\n" + "Строка после сплитирования: " + "\n");
        for (String e : strings) {

            System.out.println(e);
        }
        List<String> stringsAfter = filterCapitalizedStrings(strings);
        System.out.println("\n" + "Строка после преобразования : " + "\n");
        for (String e : stringsAfter) {
            System.out.println(e);
        }
        System.out.println("-----------------------------------");
        System.out.println("4 Задание--------------------------------");
        List<Integer> integers = new ArrayList<>();
        System.out.println("\n" + "Список до: " + "\n");

        for (int i = 0; i < 10; i++) {

            integers.add(random.nextInt(10));
            System.out.println(integers.get(i));
        }
        List<Integer> integersAfter = squareList(integers);
        System.out.println("\n" + "Список после возведения в квадрат: " + "\n");
        for (Integer i : integersAfter) {
            System.out.println(i);
        }
        System.out.println("-----------------------------------");
        System.out.println("5 Задание--------------------------------");
        System.out.println("\tНапишите функцию, которая принимает на вход список строк и возвращает новый список, содержащий только те строки, которые содержат заданную подстроку.");
        List<String> filteredStrings = filterStrings(strings, substring);
        System.out.println(filteredStrings);
        System.out.println("-----------------------------------");
        System.out.println("6 Задание--------------------------------");
        System.out.println("\tНапишите функцию, которая принимает на вход список целых чисел и возвращает новый список, содержащий только те числа, которые делятся на заданное число без остатка.");
        int divisor = 3;
        List<Integer> divisibleNumbers = filterDivisibleNumbers(arr2, divisor);
        System.out.println(divisibleNumbers);
        System.out.println("-----------------------------------");
        System.out.println("7 Задание--------------------------------");
        System.out.println("\tНапишите функцию, которая принимает на вход список строк и возвращает новый список, содержащий только те строки, которые имеют длину больше заданного значения.");
        int minLength = 5;
        List<String> filteredString = filterLongerThan(strings, minLength);
        System.out.println(filteredString);
        System.out.println("-----------------------------------");
        System.out.println("8 Задание--------------------------------");
        System.out.println("\tНапишите функцию, которая принимает на вход список целых чисел и возвращает новый список, содержащий только те числа, которые больше заданного значения.");
        int threshold = 5;
        List<Integer> greaterThan = filterGreaterThan(arr2, threshold);
        System.out.println(greaterThan);
        System.out.println("-----------------------------------");
        System.out.println("9 Задание--------------------------------");
        System.out.println("\tНапишите функцию, которая принимает на вход список строк и возвращает новый список, содержащий только те строки, которые содержат только буквы (без цифр и символов).");
        List<String> filterStrings = filterStringsWithOnlyLetters(strings);
        for (String str : filterStrings) {
            System.out.println(str);
        }
        System.out.println("-----------------------------------");
        System.out.println("10 Задание--------------------------------");
        System.out.println("\tНапишите функцию, которая принимает на вход список целых чисел и возвращает новый список, содержащий только те числа, которые меньше заданного значения.");
        int threshold2 = 5;
        List<Integer> lessThanThreshold = filterNumbersLessThan(arr2, threshold2);
        System.out.println(lessThanThreshold);
        System.out.println("-----------------------------------");
    }

    public static int[] filterEvenNumbers(int[] arr) {
        return Arrays.stream(arr).filter(x -> x % 2 == 0).toArray();
    }

    public static int[] findCommonElements(int[] arr1, int[] arr2) {
        return Arrays.stream(arr1)
                .filter(x -> Arrays.stream(arr2)
                        .anyMatch(y -> y == x))
                .toArray();
    }

    public static List<String> filterCapitalizedStrings(List<String> list) {
        return list.stream()
                .filter(s -> Character.isUpperCase(s.charAt(0)))
                .collect(Collectors.toList());
    }

    public static List<Integer> squareList(List<Integer> list) {
        return list.stream().map(x -> x * x).collect(Collectors.toList());
    }

    public static List<String> filterStrings(List<String> strings, String substring) {
        List<String> result = new ArrayList<>();
        for (String str : strings) {
            if (str.contains(substring)) {
                result.add(str);
            }
        }
        return result;
    }

    public static List<Integer> filterDivisibleNumbers(int[] numbers, int divisor) {
        List<Integer> divisibleNumbers = new ArrayList<>();

        for (int number : numbers) {
            if (number % divisor == 0) {
                divisibleNumbers.add(number);
            }
        }

        return divisibleNumbers;
    }

    public static List<String> filterLongerThan(List<String> strings, int minLength) {
        List<String> longerThan = new ArrayList<>();

        for (String str : strings) {
            if (str.length() > minLength) {
                longerThan.add(str);
            }
        }

        return longerThan;
    }

    public static List<Integer> filterGreaterThan(int[] numbers, int threshold) {
        List<Integer> greaterThan = new ArrayList<>();

        for (int number : numbers) {
            if (number > threshold) {
                greaterThan.add(number);
            }
        }

        return greaterThan;
    }

    public static List<String> filterStringsWithOnlyLetters(List<String> strings) {
        List<String> result = new ArrayList<>();
        for (String str : strings) {
            if (str.chars().allMatch(Character::isLetter)) {
                result.add(str);
            }
        }
        return result;
    }

    public static List<Integer> filterNumbersLessThan(int[] numbers, int threshold) {
        List<Integer> lessThanThreshold = new ArrayList<>();
        for (int number : numbers) {
            if (number < threshold) {
                lessThanThreshold.add(number);
            }
        }
        return lessThanThreshold;
    }
}