public class n4{
    public static void main(String[] args) throws InterruptedException {
        Thread t1 = new Thread(() -> {
            System.out.println(Thread.currentThread().getName() +": 1");
        });
        Thread t2 = new Thread(() -> {
            System.out.println(Thread.currentThread().getName() +": 2");
        });
        Thread t3 = new Thread(() -> {
            System.out.println(Thread.currentThread().getName() +": 3");
        });
        Thread t4 = new Thread(() -> {
            System.out.println(Thread.currentThread().getName() +": 4");
        });
        t1.start();
        t1.join();
        t2.start();
        t2.join();
        t3.start();
        t3.join();
        t4.start();
        t4.join();
    }
}