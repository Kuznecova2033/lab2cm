import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

public class n5 {
    public static void main(String[] args) {
        int[] array = {1, 4, 3, 2, 5, 6, 7, 8, 9, 10, 11, 12, 7};
        List<Thread> threads = new ArrayList<>();
        AtomicInteger maxValue = new AtomicInteger(Integer.MIN_VALUE);

        for (int i = 0; i < array.length; i += array.length / Runtime.getRuntime().availableProcessors()) {
            final int start = i;
            final int end = Math.min(i + array.length / Runtime.getRuntime().availableProcessors(), array.length);
            Thread thread = new Thread(() -> {
                int localMax = array[start];
                for (int j = start + 1; j < end; j++) {
                    if (array[j] > localMax) {
                        localMax = array[j];
                    }
                }
                maxValue.accumulateAndGet(localMax, Math::max);
            });
            threads.add(thread);
            thread.start();
        }

        for (Thread t : threads) {
            try {
                t.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        System.out.println("Максимальный элемент: " + maxValue.get());
    }
}
