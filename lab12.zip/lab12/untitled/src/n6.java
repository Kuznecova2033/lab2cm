import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

public class n6 {
    public static void main(String[] args) {
        int[] array = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13};
        sumArray(array);
    }

    public static void sumArray(int[] array) {
        // Получаем количество ядер процессора
        int numCores = Runtime.getRuntime().availableProcessors();

        // Разделяем массив на части
        List<int[]> parts = divideArray(array, numCores);

        // Суммируем элементы каждой части
        AtomicInteger totalSum = new AtomicInteger(0);
        for (int[] part : parts) {
            totalSum.addAndGet(sumPart(part));
        }

        // Выводим общую сумму
        System.out.println("Общая сумма: " + totalSum);
    }

    private static List<int[]> divideArray(int[] array, int numParts) {
        List<int[]> parts = new ArrayList<>();
        int size = array.length / numParts;
        for (int i = 0; i < numParts - 1; i++) {
            parts.add(Arrays.copyOfRange(array, i  *  size, (i + 1)  *  size));
        }
        // Добавляем оставшиеся элементы в последнюю часть массива
        parts.add(Arrays.copyOfRange(array, (numParts - 1)  *  size, array.length));
        return parts;
    }

    private static int sumPart(int[] part) {
        int sum = 0;
        for (int num : part) {
            sum += num;
        }
        return sum;
    }
}
