import java.util.InputMismatchException;
import java.util.Scanner;

public class zadanie2_1 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Попытка считать массив
        try {
            System.out.println("Введите количество элементов массива:");
            int n = scanner.nextInt();
            int[] array = new int[n];

            // Попытка считывания элементов массива
            for (int i = 0; i < n; i++) {
                System.out.printf("Введите элемент %d: ", i + 1);
                array[i] = scanner.nextInt();

                // Проверка на положительность элемента
                if (array[i] <= 0) {
                    throw new IllegalArgumentException("Элемент должен быть положительным");
                }
            }

            // Вычисление среднего значения
            double average = calculateAverage(array);
            System.out.println("Среднее значение положительных элементов: " + average);
        } catch (InputMismatchException e) {
            // Обработка исключения при неверном вводе
            System.out.println("Ошибка ввода: введен некорректный формат");
        } catch (IllegalArgumentException e) {
            // Обработка исключения при отрицательном элементе
            System.out.println("Ошибка: " + e.getMessage());
        } finally {
            // Закрытие сканера независимо от результата
            scanner.close();
        }
    }

    private static double calculateAverage(int[] array) {
        int sum = 0;
        for (int element : array) {
            sum += element;
        }
        return sum / array.length;
    }
}