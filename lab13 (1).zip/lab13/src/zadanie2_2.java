import java.util.InputMismatchException;
import java.util.Scanner;

public class zadanie2_2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Попытка считать размерность матрицы
        try {
            System.out.println("Введите количество строк и столбцов матрицы:");
            int rows = scanner.nextInt();
            int cols = scanner.nextInt();
            int[][] matrix = new int[rows][cols];

            // Попытка считывания элементов матрицы
            for (int i = 0; i < rows; i++) {
                for (int j = 0; j < cols; j++) {
                    System.out.printf("Введите элемент [%d][%d]: ", i + 1, j + 1);
                    matrix[i][j] = scanner.nextInt();
                }
            }

            // Попытка вывода столбца с заданным номером
            System.out.println("Введите номер столбца для вывода:");
            int columnIndex = scanner.nextInt() - 1; // Индексация с 0
            printColumn(matrix, columnIndex);
        } catch (InputMismatchException e) {

            // Обработка исключения при неверном вводе
            System.out.println("Ошибка ввода: введен некорректный формат");
        } catch (ArrayIndexOutOfBoundsException e) {
            // Обработка исключения при попытке доступа к несуществующему столбцу
            System.out.println("Ошибка: столбец с таким номером отсутствует");
        } finally {
            // Закрытие сканера независимо от результата
            scanner.close();
        }
    }

    private static void printColumn(int[][] matrix, int columnIndex) {
        for (int i = 0; i < matrix.length; i++) {
            System.out.print(matrix[i][columnIndex] + " ");
        }
        System.out.println();
    }
}
