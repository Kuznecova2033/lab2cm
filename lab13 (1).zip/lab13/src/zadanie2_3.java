import java.util.InputMismatchException;
import java.util.Scanner;

public class zadanie2_3 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Попытка считать массив
        try {
            System.out.println("Введите количество элементов массива:");
            int n = scanner.nextInt();
            byte[] array = new byte[n];

            // Попытка считывания элементов массива
            for (int i = 0; i < n; i++) {
                System.out.printf("Введите элемент %d: ", i + 1);
                array[i] = scanner.nextByte(); // Используем nextByte() для чтения байта
            }

            // Вычисление суммы
            int sum = 0;
            for (byte element : array) {
                sum += element;
            }
            System.out.println("Сумма элементов массива: " + sum);
        } catch (InputMismatchException e) {
            // Обработка исключения при неверном вводе
            System.out.println("Ошибка ввода: введен некорректный формат");
        } catch (NumberFormatException e) {
            // Обработка исключения при неправильном формате числа
            System.out.println("Ошибка: введенное число не соответствует формату типа byte");
        } catch (ArrayIndexOutOfBoundsException e) {
            // Обработка исключения при попытке доступа к несуществующему элементу массива
            System.out.println("Ошибка: индекс массива выходит за его границы");
        } finally {
            // Закрытие сканера независимо от результата
            scanner.close();
        }
    }
}
