import java.io.FileReader;

import org.apache.logging.log4j.core.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
public class jsonParser2 {
    public static void main(String[] args) {
        try {
            Scanner scanner = new Scanner(System.in);

            System.out.println("1-показать текущую библиотеку;2-поиск книги по автору;3-добавить;4-удалить данные;0-выход:");
            int j = scanner.nextInt();
            for(;j!=0;){
                if(j==1) {
                    JSONParser parser = new JSONParser();
                    Object obj = parser.parse(new FileReader("src/example-json.json"));
                    JSONObject jsonObject = (JSONObject) obj;
                    System.out.println("Key Name: " + jsonObject.keySet().iterator().next());
                    JSONArray jsonArray = (JSONArray) jsonObject.get("books");

                    for (Object o : jsonArray) {
                        JSONObject book = (JSONObject) o;
                        System.out.println("\nText Segment: " + book);
                        System.out.println("kniga: " + book.get("title"));
                        System.out.println("Author: " + book.get("author"));
                        System.out.println("god: " + book.get("year"));
                    }
                } else if(j==2){
                    System.out.println("Введите автора книги:");
                    String author = scanner.next();
                    JSONParser parser = new JSONParser();
                    Object obj = parser.parse(new FileReader("src/example-json.json"));
                    JSONObject jsonObject = (JSONObject) obj;
                    JSONArray jsonArray = (JSONArray) jsonObject.get("books");
                    for (Object o : jsonArray) {
                        JSONObject book = (JSONObject) o;
                        if(book.get("author").equals(author)){
                            System.out.println("\nText Segment: " + book);
                            System.out.println("HashName kuduru: " + book.get("title"));
                            System.out.println("Author: " + book.get("author"));
                            System.out.println("Loan warnings: " + book.get("year"));
                        }
                    }
                } else if(j==3){
                    System.out.println("Введите автора книги:");
                    String author = scanner.next();
                    System.out.println("Введите название книги:");
                    String title = scanner.next();
                    System.out.println("Введите год издания книги:");
                    int year = scanner.nextInt();
                    JSONParser parser = new JSONParser();
                    Object obj = parser.parse(new FileReader("src/example-json.json"));
                    JSONObject jsonObject = (JSONObject) obj;
                    JSONArray jsonArray = (JSONArray) jsonObject.get("books");
                    JSONObject newBook = new JSONObject();
                    newBook.put("author", author);
                    newBook.put("title", title);
                    newBook.put("year", year);
                    jsonArray.add(newBook);
                    try {
                        FileWriter file = new FileWriter("src/example-json.json");
                        file.write(jsonObject.toJSONString());
                        file.flush();
                        file.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                } else if(j==4){
                    System.out.println("Введите название книги, которую хотите удалить:");
                    String title = scanner.next();
                    JSONParser parser = new JSONParser();
                    Object obj = parser.parse(new FileReader("src/example-json.json"));
                    JSONObject jsonObject = (JSONObject) obj;
                    JSONArray jsonArray = (JSONArray) jsonObject.get("books");
                    for (Object o : jsonArray) {
                        JSONObject book = (JSONObject) o;
                        if(book.get("title").equals(title)){
                            jsonArray.remove(book);
                            break;
                        }
                    }
                    try {
                        FileWriter file = new FileWriter("src/example-json.json");
                        file.write(jsonObject.toJSONString());
                        file.flush();
                        file.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                System.out.println("1-показать текущую библиотеку;2-поиск книги по автору;3-добавить;4-удалить данные;0-выход:");
                j = scanner.nextInt();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}