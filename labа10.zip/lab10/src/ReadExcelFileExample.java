import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadExcelFileExample {
    public static void main(String[] args) {
        String filePath = "src/example3.xlsx";

        try {
            FileInputStream inputStream = new FileInputStream(filePath);
            XSSFWorkbook workbook = new XSSFWorkbook(inputStream);

            XSSFSheet sheet = workbook.getSheet("товар");
            if (sheet == null) {
                throw new IllegalArgumentException("Лист 'товар' не найден в Excel файле.");
            }

            for (Row row : sheet) {
                for (Cell cell : row) {
                    System.out.print(cell.toString() + "\t");
                }
                System.out.println();
            }

            workbook.close();
            inputStream.close();
        } catch (FileNotFoundException e) {
            System.err.println("Файл не найден: " + e.getMessage());
        } catch (IOException e) {
            System.err.println("Ошибка ввода-вывода: " + e.getMessage());
        } catch (IllegalArgumentException e) {
            System.err.println("Ошибка при чтении Excel файла: " + e.getMessage());
            System.err.println("Рекомендация: Проверьте наличие листа 'товар' в файле.");
        } catch (Exception e) {
            System.err.println("Произошла ошибка: " + e.getMessage());
        }

        // Добавить возможность повторного запуска программы

    }
}