import org.jsoup.Connection;
import org.jsoup.HttpStatusException;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.nodes.Node;
import org.jsoup.select.Elements;

import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

public class NewsParser3 {
    public static void main(String[] args) {
        int retryCount = 3; // Количество попыток подключения к сайту
        int retry = 0;

        while (retry < retryCount) {
            try {
                Connection.Response response = Jsoup.connect("http://fat.urfu.ru/index.html").execute();
                if (response.statusCode() == 200) {
                    Document doc = Jsoup.connect("http://fat.urfu.ru/index.html").get();
                    Elements newsParent = doc.select("body > table > tbody > tr > td > div > table > tbody > tr:nth-child(5) > td:nth-child(3) > table > tbody > tr > td:nth-child(1)");

                    for (int i = 3; i < 20; i++) {
                        if (!(i % 2 == 0)) {
                            List<Node> nodes = newsParent.get(0).childNodes();
                            System.out.println("Tema: " + ((Element) nodes.get(i)).getElementsByClass("blocktitle").get(0).childNodes().get(0));
                            System.out.println("Data: " + ((Element) nodes.get(i)).getElementsByClass("blockdate").get(0).childNodes().get(0) + "\n");

                            FileWriter file = new FileWriter("src/news.txt", true);
                            file.write("Tema: " + ((Element) nodes.get(i)).getElementsByClass("blocktitle").get(0).childNodes().get(0) + "\nData: " + ((Element) nodes.get(i)).getElementsByClass("blockdate").get(0).childNodes().get(0) + "\n");
                            file.close();
                        }
                    }
                    break;
                }
            } catch (HttpStatusException e) {
                System.out.println("HTTP error fetching page: " + e.getMessage());
                retry++;
            } catch (IOException e) {
                e.printStackTrace();
                retry++;
            }
        }

        if (retry == retryCount) {
            System.out.println("Failed to connect after " + retryCount + " attempts.");
        }
    }
}
