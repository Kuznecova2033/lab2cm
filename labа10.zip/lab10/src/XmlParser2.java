import java.io.File;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;
import java.util.Scanner;

public class XmlParser2 {
    public static void main(String[] args) {
        try {
            Scanner scanner = new Scanner(System.in);

            System.out.println("1-показать текущую библиотеку;2-записать;3-поиск книги по автору или году издания;4-удалить данные;0-выход:");
            int j = scanner.nextInt();
            for(;j!=0;){
                if(j==1) {
                    File inputFile = new File("src/example.xml");
                    DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
                    DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
                    Document doc = dBuilder.parse(inputFile);
                    doc.getDocumentElement().normalize();
                    System.out.println("Корневой элемент: *" + doc.getDocumentElement().getNodeName());
                    NodeList nodeList = doc.getElementsByTagName("book");

                    for (int i = 0; i < nodeList.getLength(); i++) {
                        Node node = nodeList.item(i);
                        System.out.println("\nТекущий элемент: *" + node.getNodeName());
                        if (node.getNodeType() == Node.ELEMENT_NODE) {
                            Element element = (Element) node;
                            System.out.println("Название книги: *" + element.getElementsByTagName("title").item(0).getTextContent());
                            System.out.println("автор: *" + element.getElementsByTagName("author").item(0).getTextContent());
                            System.out.println("Год издания: " + element.getElementsByTagName("year").item(0).getTextContent());
                        }
                    }
                } else if (j==2){
                    File inputFile = new File("src/example.xml");
                    DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
                    DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
                    Document doc = dBuilder.parse(inputFile);
                    javax.xml.transform.Transformer transformer =
                            javax.xml.transform.TransformerFactory.newInstance().newTransformer();
                    javax.xml.transform.dom.DOMSource source = new  javax.xml.transform.dom.DOMSource(doc);
                    javax.xml.transform.stream.StreamResult result = new javax.xml.transform.stream.StreamResult(new File("src/example.xml"));

                    System.out.println("Введите данные для новой книги:");
                    String nn = scanner.nextLine();
                    System.out.println("Название книги:");
                    String title = scanner.nextLine();
                    System.out.println("Автор:");
                    String author = scanner.nextLine();
                    System.out.println("Год издания:");
                    int year = scanner.nextInt();
                    scanner.nextLine(); // Сбрасываем символ новой строки после ввода числа
                    // Создаем новый элемент "book"
                    Element newBookElement = doc.createElement("book");
                    doc.getDocumentElement().appendChild(newBookElement);
                    // Добавляем элементы "title", "author" и "year" в новый элемент "book"
                    Element titleElement = doc.createElement("title");
                    titleElement.appendChild(doc.createTextNode(title));
                    newBookElement.appendChild(titleElement);
                    Element authorElement = doc.createElement("author");
                    authorElement.appendChild(doc.createTextNode(author));
                    newBookElement.appendChild(authorElement);
                    Element yearElement = doc.createElement("year");
                    yearElement.appendChild(doc.createTextNode(String.valueOf(year)));
                    newBookElement.appendChild(yearElement);
                    // Сохраняем изменения в файл
                    transformer.transform(source, result);
                } else if (j==3){
                    File inputFile = new File("src/example.xml");
                    DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
                    DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
                    Document doc = dBuilder.parse(inputFile);
                    System.out.println("Введите данные для поиска:");
                    System.out.println("1-поиск по автору;2-поиск по году издания:");
                    int searchType = scanner.nextInt();
                    String nn = scanner.nextLine();
                    String searchValue = scanner.nextLine();

                    NodeList nodeList = doc.getElementsByTagName("book");
                    for (int i = 0; i < nodeList.getLength(); i++) {
                        Node node = nodeList.item(i);
                        if (node.getNodeType() == Node.ELEMENT_NODE) {
                            Element element = (Element) node;
                            if (searchType == 1) {
                                if (element.getElementsByTagName("author").item(0).getTextContent().equals(searchValue)) {
                                    System.out.println("Название книги:  * " + element.getElementsByTagName("title").item(0).getTextContent());
                                    System.out.println("автор:  * " + element.getElementsByTagName("author").item(0).getTextContent());
                                    System.out.println("Год издания: " + element.getElementsByTagName("year").item(0).getTextContent());
                                }
                            } else if (searchType == 2) {
                                if (element.getElementsByTagName("year").item(0).getTextContent().equals(searchValue)) {
                                    System.out.println("Название книги:  * " + element.getElementsByTagName("title").item(0).getTextContent());
                                    System.out.println("автор:  * " + element.getElementsByTagName("author").item(0).getTextContent());
                                    System.out.println("Год издания: " + element.getElementsByTagName("year").item(0).getTextContent());
                                }
                            }
                        }
                    }
                } else if (j==4){
                    System.out.println("Введите название книги для удаления:");
                    String titleToDelete = scanner.next();
                    File inputFile = new File("src/example.xml");
                    DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
                    DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
                    Document doc = dBuilder.parse(inputFile);
                    doc.getDocumentElement().normalize();
                    NodeList nodeList = doc.getElementsByTagName("book");

                    for (int i = 0; i < nodeList.getLength(); i++) {
                        Node node = nodeList.item(i);
                        if (node.getNodeType() == Node.ELEMENT_NODE) {
                            Element element = (Element) node;
                            if (element.getElementsByTagName("title").item(0).getTextContent().equals(titleToDelete)) {
                                node.getParentNode().removeChild(node);
                            }
                        }
                    }
                    // Запись изменений обратно в файл
                    javax.xml.transform.TransformerFactory transformerFactory =  javax.xml.transform.TransformerFactory.newInstance();
                    javax.xml.transform.Transformer transformer = transformerFactory.newTransformer();
                    javax.xml.transform.dom.DOMSource source = new javax.xml.transform.dom.DOMSource(doc);
                    javax.xml.transform.stream.StreamResult result = new javax.xml.transform.stream.StreamResult(new File("src/example.xml"));
                    transformer.transform(source, result);
                    }
                System.out.println("1-показать текущую библиотеку;2-записать;3-поиск книги по автору или году издания;4-удалить данные;0-выход:");
                j = scanner.nextInt();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
